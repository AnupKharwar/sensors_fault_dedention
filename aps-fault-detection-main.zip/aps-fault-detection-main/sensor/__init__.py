from dotenv import load_dotenv
print(f"Loading environment variable from .env file")
load_dotenv()